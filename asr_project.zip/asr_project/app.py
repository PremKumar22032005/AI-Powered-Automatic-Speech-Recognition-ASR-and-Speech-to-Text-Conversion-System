"""Streamlit interface for the ASR (Automatic Speech Recognition) project."""
from __future__ import annotations

import tempfile
from pathlib import Path

import streamlit as st

from transcriber import transcribe_audio

st.set_page_config(page_title="ASR Speech to Text", page_icon="🎙️", layout="centered")
st.title("🎙️ Automatic Speech Recognition")
st.write("Upload an audio recording and convert speech into editable text.")
st.caption("Runs locally on your computer after setup. The selected Whisper model downloads on first use.")

with st.sidebar:
    st.header("Transcription settings")
    model_size = st.selectbox("Model size", ["tiny", "base", "small", "medium", "large-v3"], index=1,
                              help="Tiny/base are faster; larger models may be more accurate but need more memory.")
    language_choice = st.selectbox("Audio language", ["Auto-detect", "English", "Tamil", "Hindi", "Malayalam", "Telugu", "Kannada", "French", "Spanish"])
    language_codes = {"English": "en", "Tamil": "ta", "Hindi": "hi", "Malayalam": "ml", "Telugu": "te", "Kannada": "kn", "French": "fr", "Spanish": "es"}
    language = language_codes.get(language_choice)

uploaded_file = st.file_uploader("Choose an audio file", type=["wav", "mp3", "m4a", "ogg", "flac", "webm"])
if uploaded_file:
    st.audio(uploaded_file)
    if st.button("Transcribe audio", type="primary", use_container_width=True):
        suffix = Path(uploaded_file.name).suffix or ".audio"
        temp_path = None
        try:
            with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as temp_file:
                temp_file.write(uploaded_file.getvalue())
                temp_path = temp_file.name
            with st.spinner("Transcribing… longer recordings may take a few minutes."):
                result = transcribe_audio(temp_path, model_size=model_size, language=language)
            st.success("Transcription complete")
            if result.language:
                confidence = f" ({result.language_probability:.0%} confidence)" if result.language_probability is not None else ""
                st.caption(f"Detected language: {result.language}{confidence}")
            st.text_area("Recognized text", value=result.text, height=240)
            st.download_button("Download transcript (.txt)", data=result.text, file_name="transcript.txt", mime="text/plain", use_container_width=True)
            if result.segments:
                with st.expander("View timestamped segments"):
                    for segment in result.segments:
                        st.write(f"`{segment['start']:.2f}s – {segment['end']:.2f}s`  {segment['text']}")
        except Exception as exc:
            st.error(f"Transcription failed: {exc}")
            st.info("Check that the audio file is valid, FFmpeg is installed, and your computer has enough memory.")
        finally:
            if temp_path and Path(temp_path).exists():
                Path(temp_path).unlink()
else:
    st.info("Supported formats: WAV, MP3, M4A, OGG, FLAC, and WEBM.")

st.divider()
st.caption("Project demo · Python · Streamlit · faster-whisper · OpenAI Whisper models")
