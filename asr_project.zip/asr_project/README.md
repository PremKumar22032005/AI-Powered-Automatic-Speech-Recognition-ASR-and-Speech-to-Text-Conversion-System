# Automatic Speech Recognition (ASR) — Speech to Text

A beginner-friendly Python web app that converts speech in an uploaded audio recording into text. It uses the `faster-whisper` implementation of Whisper and a Streamlit interface. It can display the detected language, show timestamped text segments, and download the transcript as a `.txt` file.

## Features

- Upload audio in WAV, MP3, M4A, OGG, FLAC, or WEBM format.
- Choose a Whisper model size (`tiny`, `base`, `small`, `medium`, or `large-v3`).
- Automatically detect the spoken language or select a supported language.
- View and download the recognized transcript.
- Inspect timestamped transcript segments.
- Run locally; audio processing is performed on the computer running the app.

## Technologies used

- **Python 3.10+** — application logic
- **Streamlit** — web interface
- **faster-whisper** — speech recognition inference
- **Whisper models** — multilingual speech-to-text model weights downloaded when a model is first used
- **FFmpeg** — audio decoding support used by faster-whisper
- **unittest** — basic automated tests

## Requirements

- Python 3.10 or newer
- FFmpeg installed and available on your system PATH
- Internet connection for the initial model download
- Sufficient disk space and RAM for the selected model; `tiny` or `base` is recommended for a first run on a typical laptop

## Run locally

### 1. Install FFmpeg

- **Windows:** Install FFmpeg and add its `bin` folder to PATH.
- **macOS:** `brew install ffmpeg`
- **Ubuntu/Debian:** `sudo apt update && sudo apt install ffmpeg`

Check the installation with `ffmpeg -version`.

### 2. Create and activate a virtual environment

**Windows (PowerShell):**

```powershell
py -3.10 -m venv .venv
.\.venv\Scripts\Activate.ps1
```

**macOS/Linux:**

```bash
python3 -m venv .venv
source .venv/bin/activate
```

### 3. Install Python packages

```bash
python -m pip install --upgrade pip
pip install -r requirements.txt
```

### 4. Start the app

```bash
streamlit run app.py
```

Streamlit will print a local address (usually `http://localhost:8501`). Open it in your browser, upload an audio file, choose the settings, and click **Transcribe audio**. The first run downloads the selected model and can take longer than later runs.

## Run tests

From the project root, run:

```bash
python -m unittest discover -s tests -v
```

The tests check missing-file handling and transcript assembly using a mocked model, so the test suite does not download Whisper model weights.

## Upload to GitHub

1. Create a new empty repository on GitHub, for example `asr-speech-to-text`.
2. Open a terminal in this project folder.
3. Run the following commands, replacing the placeholder with your repository URL:

```bash
git init
git add .
git commit -m "Build ASR speech-to-text app"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/asr-speech-to-text.git
git push -u origin main
```

Do not commit virtual environments, audio files containing private speech, or downloaded model files.

## Limitations

- Recognition quality depends on audio clarity, accent, background noise, and the chosen model.
- Larger models are slower and require more memory.
- This is a practical ASR demo, not a certified transcription service. Review the generated transcript before relying on it.
- Available language choices in the interface are a curated subset; Whisper supports additional languages.

## Project structure

```text
asr_project/
├── app.py
├── transcriber.py
├── requirements.txt
├── README.md
├── .gitignore
└── tests/
    └── test_transcriber.py
```

## License

For academic use, add a license file if your institution or team requires one. Check the licenses of dependencies and model weights before redistributing them.
