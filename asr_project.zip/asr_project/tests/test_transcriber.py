import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from transcriber import TranscriptionResult, transcribe_audio


class FakeSegment:
    def __init__(self, start, end, text):
        self.start = start
        self.end = end
        self.text = text


class FakeInfo:
    language = "en"
    language_probability = 0.98


class FakeModel:
    def __init__(self, *args, **kwargs):
        pass

    def transcribe(self, *args, **kwargs):
        return iter([FakeSegment(0, 1.2, " Hello "), FakeSegment(1.2, 2.1, "world.")]), FakeInfo()


class TranscriberTests(unittest.TestCase):
    def test_missing_audio_file_raises(self):
        with self.assertRaises(FileNotFoundError):
            transcribe_audio("this-file-should-not-exist.wav")

    def test_transcription_combines_segments(self):
        with tempfile.NamedTemporaryFile(suffix=".wav") as audio:
            # Patch the optional dependency so the test does not download a model.
            import sys
            from types import SimpleNamespace
            with patch.dict(sys.modules, {"faster_whisper": SimpleNamespace(WhisperModel=FakeModel)}):
                result = transcribe_audio(audio.name)
        self.assertIsInstance(result, TranscriptionResult)
        self.assertEqual(result.text, "Hello world.")
        self.assertEqual(result.language, "en")
        self.assertEqual(len(result.segments), 2)
        self.assertEqual(result.segments[0]["start"], 0.0)


if __name__ == "__main__":
    unittest.main()
