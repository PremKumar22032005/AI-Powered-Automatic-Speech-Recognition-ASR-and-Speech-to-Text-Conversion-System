"""Speech-to-text utilities powered by faster-whisper."""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable


@dataclass
class TranscriptionResult:
    text: str
    language: str | None
    language_probability: float | None
    segments: list[dict[str, Any]]


def transcribe_audio(
    audio_path: str | Path,
    model_size: str = "base",
    language: str | None = None,
    device: str = "cpu",
    compute_type: str = "int8",
) -> TranscriptionResult:
    """Transcribe an audio file and return text plus timestamped segments.

    The Whisper model is downloaded automatically on first use. Supported input
    formats depend on FFmpeg, which faster-whisper uses to decode audio.
    """
    path = Path(audio_path)
    if not path.exists() or not path.is_file():
        raise FileNotFoundError(f"Audio file was not found: {path}")

    try:
        from faster_whisper import WhisperModel
    except ImportError as exc:  # pragma: no cover - depends on installed extras
        raise RuntimeError(
            "faster-whisper is not installed. Run: pip install -r requirements.txt"
        ) from exc

    model = WhisperModel(model_size, device=device, compute_type=compute_type)
    segments_iter, info = model.transcribe(
        str(path), language=language or None, vad_filter=True, beam_size=5
    )
    segments = [
        {"start": float(segment.start), "end": float(segment.end), "text": segment.text.strip()}
        for segment in segments_iter
    ]
    full_text = " ".join(item["text"] for item in segments).strip()
    return TranscriptionResult(
        text=full_text,
        language=getattr(info, "language", None),
        language_probability=getattr(info, "language_probability", None),
        segments=segments,
    )
